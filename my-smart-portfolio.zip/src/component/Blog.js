import React from 'react';

const Blog = () => {
    return (
        <div className='text-7xl flex items-center justify-center py-36'>
            <h1>Coming Soon</h1>
        </div>
    );
};

export default Blog;